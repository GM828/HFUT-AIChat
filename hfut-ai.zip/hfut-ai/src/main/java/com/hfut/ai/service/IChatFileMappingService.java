package com.hfut.ai.service;

import com.hfut.ai.entity.po.ChatFileMapping;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author GM
 * @since 2025-06-23
 */
public interface IChatFileMappingService extends IService<ChatFileMapping> {

}
